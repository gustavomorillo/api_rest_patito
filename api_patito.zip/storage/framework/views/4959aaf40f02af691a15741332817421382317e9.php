


<p>Su nueva contraseña es: <?php echo e($data['password']); ?> </p>