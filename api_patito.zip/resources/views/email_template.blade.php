


<p>Su nueva contraseña es: {{$data['password']}} </p>